package engineTester;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import audio.AudioMaster;
import audio.Source;
import entities.Camera;
import entities.Entity;
import entities.Light;
import entities.Player;
import guis.GuiRenderer;
import guis.GuiTexture;
import models.RawModel;
import models.TexturedModel;
import renderEngine.DisplayManager;
import renderEngine.Loader;
import renderEngine.MasterRenderer;
import renderEngine.OBJLoader;
import terrains.Terrain;
import textures.ModelTexture;
import textures.TerrainTexture;
import textures.TerrainTexturePack;
import webIntegration.loginForm;
import webIntegration.variableSender;

public class MainGameLoop {

	public static void main(String[] args) {
		
		boolean wasPressed = false;
		
		String uid = loginForm.getUsername();
		
		System.setProperty("org.lwjgl.librarypath", new File("lib/natives").getAbsolutePath());

		 DisplayManager.createDisplay();
	        Loader loader = new Loader();
	        
	        TerrainTexture backgroundTexture = new TerrainTexture(loader.loadTexture("grassy"));
	        TerrainTexture rTexture = new TerrainTexture(loader.loadTexture("dirt"));
	        TerrainTexture gTexture = new TerrainTexture(loader.loadTexture("grassFlowers"));
	        TerrainTexture bTexture = new TerrainTexture(loader.loadTexture("path"));
	        
	        TerrainTexturePack texturePack = new TerrainTexturePack(backgroundTexture, rTexture, gTexture, bTexture);
	        TerrainTexture blendMap = new TerrainTexture(loader.loadTexture("blendMap"));
	        
			ModelTexture fernTextureAtlas = new ModelTexture(loader.loadTexture("fern"));
			fernTextureAtlas.setNumberOfRows(2);
	         
	        TexturedModel pine = new TexturedModel(OBJLoader.loadObjModel("pine", loader), new ModelTexture(loader.loadTexture("pine")));
	        TexturedModel lamp = new TexturedModel(OBJLoader.loadObjModel("lamp", loader), new ModelTexture(loader.loadTexture("lamp")));
	        TexturedModel fern = new TexturedModel(OBJLoader.loadObjModel("fern", loader), fernTextureAtlas);
	        pine.getTexture().setHasTransparency(true);
	        lamp.getTexture().setUseFakeLightning(true);
	        fern.getTexture().setHasTransparency(true);
	        fern.getTexture().setUseFakeLightning(true);
	        
	        Terrain terrain = new Terrain(0, -1, loader, texturePack, blendMap, "heightmap");
	        List<Terrain> terrains = new ArrayList<Terrain>();
	        terrains.add(terrain);
	        
	        RawModel PlayerModel = OBJLoader.loadObjModel("person", loader);
	        TexturedModel PlayerTexturedModel = new TexturedModel(PlayerModel, new ModelTexture(loader.loadPlayerTexture("skin")));
	        
	        Player player = new Player(PlayerTexturedModel, new Vector3f(900, 10, -900), 0, 0, 0, 1);
	        
	        List<Entity> entities = new ArrayList<Entity>();
	        Random random = new Random(8376413);
	        for (int i = 0; i < 300; i++) {
	            if (i % 3 == 0) {
	                float x = random.nextFloat() * 1800;
	                float z = random.nextFloat() * -1800;
	                    float y = terrain.getHeightOfTerrain(x, z);
	                    entities.add(new Entity(fern, random.nextInt(4), new Vector3f(x, y, z), 0,random.nextFloat() * 360, 0, 3));
	            }
	            if (i % 2 == 0) {
	                float x1 = random.nextFloat() * 1800;
	                float z1 = random.nextFloat() * -1800;
	                	float y1 = terrain.getHeightOfTerrain(x1, z1);
	                	entities.add(new Entity(pine, new Vector3f(x1, y1, z1), 0,  random.nextFloat() * 360, 0, random.nextFloat() * 0.8f + 5));
	            }
	        }
	         
	        MasterRenderer renderer = new MasterRenderer(loader);
	        
	        List<Light> lights = new ArrayList<Light>();
	        lights.add(new Light(new Vector3f(0, 10000, 7000), new Vector3f(1, 1, 1)));
	        //lights.add(new Light(new Vector3f(984, 11, -1100), new Vector3f(2, 2, 2), new Vector3f(1,0.002f,0.002f)));
	        
	        entities.add(new Entity(lamp, new Vector3f(984,-15,-1100),0,100,0,2));
	        
	        Camera camera = new Camera(player);  
	        
	        List<GuiTexture> guis = new ArrayList<GuiTexture>();
	        GuiTexture logo = new GuiTexture(loader.loadTexture("walksimulator"), new Vector2f(-0.8f, 0.9f), new Vector2f(0.20f, 0.0625f));
	        guis.add(logo);
	        
	        GuiRenderer guiRenderer = new GuiRenderer(loader);
	        
	        // ======== AUDIO ========
	        AudioMaster.init();
	        AudioMaster.setListenerData(0, 0, 0);
	        
	        int backgroundambientbuffer = AudioMaster.loadSound("res/audio/background-ambient.wav");
	        Source backgroundambient = new Source();
	        backgroundambient.play(backgroundambientbuffer);
	        backgroundambient.setVolume(0.08f);
			
	        int footstepsbuffer = AudioMaster.loadSound("res/audio/footsteps.wav");
			Source footsteps = new Source();
			footsteps.setLooping(true);
	        // ======= END AUDIO =======
	        
	        while(!Display.isCloseRequested() && !Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)){
				if (!(Keyboard.isKeyDown(Keyboard.KEY_W) || Keyboard.isKeyDown(Keyboard.KEY_S)  || Keyboard.isKeyDown(Keyboard.KEY_A) || Keyboard.isKeyDown(Keyboard.KEY_D)) && wasPressed){
					wasPressed = false;
					footsteps.pause();
				} else if ((Keyboard.isKeyDown(Keyboard.KEY_W) || Keyboard.isKeyDown(Keyboard.KEY_S)  || Keyboard.isKeyDown(Keyboard.KEY_A) || Keyboard.isKeyDown(Keyboard.KEY_D)) && !wasPressed){
					wasPressed = true;
					if(footsteps.isHasBeenPaused()){
			        footsteps.continuePlaying();
					} else {
						footsteps.play(footstepsbuffer);
					}
				}
	            player.move(terrain);
	            camera.move();
	            renderer.processEntity(player);
	            renderer.processTerrain(terrain);
	            for(Entity entity:entities){
	                renderer.processEntity(entity);
	            }
	            renderer.render(lights, camera);
	            guiRenderer.render(guis);
	            DisplayManager.updateDisplay();
	        }
	    backgroundambient.delete();    
        AudioMaster.cleanUp();
		renderer.cleanUp();
		loader.cleanUp();
		DisplayManager.closeDisplay();
		Float dist = player.getDistanceTraveled() * 0.12f;
        variableSender.sendVariable(uid, Float.toString(dist));
	}

}
