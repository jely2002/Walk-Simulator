# Java-Game

Progress:
  - Window (Done)
  - Render something in window (Done)
  - Shader classed (Done)
  
Goal:
  - 3D walk simulator
  - With stats going to a web page.
